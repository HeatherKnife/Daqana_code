daqana_v6f1 readme file (Diego Tarrio, 2019/10/25).

The new version daqana_v6f1 is created by Diego, starting from the previous version (daqana_v6e4) that was used by Diego for the analysis of PPACs, and that is stored in the Dropbox folder of the Medley team. This present version (daqana_v6f1) is a modification of that one to try to implement some of the changes that were done by Bernardo, and that were saved, unfortunately, under the same name "daqana_v6e4" in the VERDI folder. Therefore, this new version does not use the code by Bernardo, except for a few lines of code that can be implemented here.



daqana_v6e4 readme file (Diego Tarrio, 2019/07/01).

The previous version (daqana_v6e3), that was used with one silicon detector (channel A) and three PPACs (channels B, C, D) has been lost when the hard disk of the computer at the lab crashed on 2019/06/17. No backup existed.

However, it existed a backup of the previous version, called daqana_v6e, that was the same, but with two Silicons (A and D) and two PPACs (B and C). (The "3" in daqana_v6e3 meant, originally, "3 PPACs", so that there were no versions "v6e2" or similar;  daqana_v6e3 was a direct modification of daqana_v6e).

Therefore, I create the present version (daqana_v6e4) starting from the daqana_v6e and modifying it to use 3 PPACs and 1 Silicon. I am pretty sure this was the only difference between the lost daqana_v6e3, and the earlier daqana_v6e. However, in order to not create confussion, I use a new name for the present version: daqana_v6e4.



